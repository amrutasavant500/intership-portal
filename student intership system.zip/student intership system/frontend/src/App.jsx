import { useState } from 'react';

function App() {
  const [loggedIn, setLoggedIn] = useState(false);
  const [email, setEmail] = useState("");
  const [applied, setApplied] = useState([]);

  const internships = [
    { id: 1, role: "Web Developer", company: "Google", stipend: "25k" },
    { id: 2, role: "Python Intern", company: "Infosys", stipend: "15k" },
    { id: 3, role: "Data Analyst", company: "TCS", stipend: "18k" },
    { id: 4, role: "UI/UX Design", company: "Wipro", stipend: "12k" },
  ];

  if (!loggedIn) {
    return (
      <div style={{ textAlign: 'center', marginTop: '60px', fontFamily: 'Arial' }}>
        <h1 style={{ color: '#2563eb' }}>Student Internship System 🚀</h1>
        <div style={{ border: '1px solid #ccc', width: '320px', margin: '30px auto', padding: '25px', borderRadius: '12px', boxShadow: '0 4px 10px rgba(0,0,0,0.1)' }}>
          <h3>Login Page</h3>
          <input value={email} onChange={(e) => setEmail(e.target.value)} placeholder="amrutasavant2007@gmail.com" style={{ padding: '10px', width: '90%', marginBottom: '10px' }} />
          <input placeholder="Password" type="password" style={{ padding: '10px', width: '90%', marginBottom: '20px' }} />
          <br/>
          <button onClick={() => { if (email) setLoggedIn(true) }} style={{ padding: '10px 40px', background: '#2563eb', color: 'white', border: 'none', borderRadius: '6px', cursor: 'pointer' }}>Login</button>
        </div>
      </div>
    );
  }

  return (
    <div style={{ padding: '20px', fontFamily: 'Arial', background: '#f8fafc', minHeight: '100vh' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h2>Welcome, {email} 🙏</h2>
        <button onClick={() => setLoggedIn(false)} style={{ background: 'red', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '5px' }}>Logout</button>
      </div>
      <h3>Available Internships ({applied.length} Applied)</h3>
      <div style={{ display: 'flex', gap: '15px', flexWrap: 'wrap', marginTop: '20px' }}>
        {internships.map(job => (
          <div key={job.id} style={{ border: '1px solid #ddd', padding: '15px', width: '220px', borderRadius: '10px', background: 'white' }}>
            <h4 style={{ margin: '0' }}>{job.role}</h4>
            <p>Company: <b>{job.company}</b></p>
            <p>Stipend: ₹{job.stipend}/month</p>
            <button 
              disabled={applied.includes(job.id)}
              onClick={() => setApplied([...applied, job.id])}
              style={{ background: applied.includes(job.id) ? 'gray' : 'green', color: 'white', border: 'none', padding: '8px 15px', borderRadius: '5px', width: '100%' }}
            >
              {applied.includes(job.id) ? 'Applied ✓' : 'Apply Now'}
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}
export default App;