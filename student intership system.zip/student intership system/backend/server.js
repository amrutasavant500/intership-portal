const express = require('express')
   const cors = require('cors')
   const bcrypt = require('bcryptjs')
   const jwt = require('jsonwebtoken')

   const app = express()
   const PORT = 5000
   app.use(cors())
   app.use(express.json())

   let users = []

   app.post('/api/auth/signup', async (req, res) => {
     const { name, email, password, role } = req.body
     const userExists = users.find(user => user.email === email)
     if (userExists) return res.status(400).json({ message: "User already exists" })

     const hashedPassword = await bcrypt.hash(password, 10)
     const newUser = { id: users.length + 1, name, email, password: hashedPassword, role }
     users.push(newUser)
     const token = jwt.sign({ id: newUser.id }, "secretkey")
     res.status(201).json({ message: "Signup successful", token, user: newUser })
   })
   app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})

   